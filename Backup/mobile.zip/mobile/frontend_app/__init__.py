"""Frontend app helpers (API, storage, constants)."""

