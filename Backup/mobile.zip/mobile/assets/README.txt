Put your background images here.

- Home background image:
  - File name: home_bg.jpg
  - Recommended: a “fabulous fully constructed building + interiors + gardens” image
  - Size: 1080x1920 or higher (portrait), JPG
  - Note: if missing, the app falls back to a glossy orange background

The app uses:
  assets/home_bg.jpg

